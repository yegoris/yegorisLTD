import swing._
import event._
import math._

object QuadraticEquation extends MainFrame {
  def main(args: Array[String]) {
    
    def top = new MainFrame {
title = "Quadratic Equation by Yegor Isakov Ltd"
val button = new Button {text = "Calculate"}
object factorA extends TextField { columns = 15 }
object factorB extends TextField { columns = 15 }
object factorC extends TextField { columns = 15 }

val label_D = new Label ("Discriminant =  ")
val conclusion = new Label ("\n\n\n\n")
val label_X1 = new Label ("X1 =  ")
val label_X2 = new Label ("X2 =  ")
val labelA = new Label("Enter factor A          ")
val labelB = new Label("Enter factor B          ")
val labelC = new Label("Enter factor C          ")


contents = new BoxPanel (Orientation.Vertical) {

 
contents += labelA
contents += factorA
contents += labelB
contents += factorB 
contents += labelC
contents += factorC 
contents +=  label_D
contents +=  conclusion
contents +=  label_X1
contents +=  label_X2
contents += button
border = Swing.EmptyBorder(20, 20, 20, 20)
}


 factorA.text = "0.0"
 factorB.text = "0.0"
 factorC.text = "0.0"

listenTo(button)
reactions += {
case ButtonClicked(b) =>
{
val A = factorA.text.toDouble
val B = factorB.text.toDouble
val C = factorC.text.toDouble



 if (A==0 && B!=0 ) {val X1 = -C/B; val X2 = X1
 label_X1.text = "X1 =\n\n" + X1
label_X2.text = "X2 =\n\n" + X2
label_D.text = "Discriminant =(/)"
  conclusion.text = "equation has one solution only "
} else
 
 {val D = B*B-4*A*C
 
 if (D > 0.0) {label_D.text = "Discriminant =" + D 
  conclusion.text = "equation has two solutions " 
   val X1 = (-B - sqrt(D))/2/A
val X2 = (-B + sqrt(D))/2/A 
   label_X1.text = "X1 =\n\n" + X1
label_X2.text = "X2 =\n\n" + X2
}
else
if (D == 0.0 && A!=0 && B!=0 ) {label_D.text ="Discriminant =" + D 
  conclusion.text = "equation has one solution only"
     val X1 = (-B - sqrt(D))/2/A
val X2 = (-B + sqrt(D))/2/A 
   label_X1.text = "X1 =\n\n" + X1
label_X2.text = "X2 =\n\n" + X2
}  
else if (D<0.0 || A==0 && B==0) {label_D.text ="Discriminant =" + D 
conclusion.text ="equation has no solution" + "\n\n"
 val X1 = (-B - sqrt(D))/2/A
val X2 = (-B + sqrt(D))/2/A 
   label_X1.text = "X1 = (/)"
label_X2.text = "X2 = (/)"
}} 
 }}};top.visible = true}}
  


