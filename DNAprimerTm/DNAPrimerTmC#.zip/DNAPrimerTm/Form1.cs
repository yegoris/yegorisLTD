﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DNAPrimerTm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
             
String primerINPUT = textBox1.Text;
String PRIMERinput = primerINPUT.ToUpper();

label2.Text =PRIMERinput;

//a - first nucleotide
int a=0;
int b=PRIMERinput.Length;

//number of nucleotides
int aN,tN,gN,cN;
    aN=0;
	tN=0;
	gN=0;
	cN=0;

label4.Text= System.Convert.ToString(aN);
label5.Text= System.Convert.ToString(tN);
label6.Text= System.Convert.ToString(gN);
label7.Text= System.Convert.ToString(cN);


while ( a != b)
{

//substrings of one letter-nucleotide (1) at certain position (a)
if (PRIMERinput.Substring(a,1)== "A") {aN++; label4.Text= System.Convert.ToString(aN);}
if (PRIMERinput.Substring(a,1)== "T") {tN++; label5.Text= System.Convert.ToString(tN);}
if (PRIMERinput.Substring(a,1)== "G") {gN++; label6.Text= System.Convert.ToString(gN);}
if (PRIMERinput.Substring(a,1)== "C") {cN++; label7.Text= System.Convert.ToString(cN);}

a++;

}

double Tm=4*(gN+cN)+2*(aN+tN);

label16.Text =System.Convert.ToString(Tm);
}
}
        }
    
