// SquareEquation.cpp : main project file.

#include "stdafx.h"
#include "SqEquation.h"

using namespace SquareEquation;

[STAThreadAttribute]
int main(array<System::String ^> ^args)
{
	// Enabling Windows XP visual effects before any controls are created
	MessageBox::Show("This is solution of equations like axx+bx+c=0 by Yegor Isakov LTD");
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false); 

	// Create the main window and run it
	Application::Run(gcnew SqEquation());
	return 0;
}
